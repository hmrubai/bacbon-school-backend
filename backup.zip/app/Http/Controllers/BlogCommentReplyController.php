<?php

namespace App\Http\Controllers;

use App\BlogCommentReply;
use Illuminate\Http\Request;

class BlogCommentReplyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BlogCommentReply  $blogCommentReply
     * @return \Illuminate\Http\Response
     */
    public function show(BlogCommentReply $blogCommentReply)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BlogCommentReply  $blogCommentReply
     * @return \Illuminate\Http\Response
     */
    public function edit(BlogCommentReply $blogCommentReply)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BlogCommentReply  $blogCommentReply
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BlogCommentReply $blogCommentReply)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BlogCommentReply  $blogCommentReply
     * @return \Illuminate\Http\Response
     */
    public function destroy(BlogCommentReply $blogCommentReply)
    {
        //
    }
}
