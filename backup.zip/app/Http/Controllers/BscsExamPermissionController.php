<?php

namespace App\Http\Controllers;

use App\BscsExamPermission;
use Illuminate\Http\Request;

class BscsExamPermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BscsExamPermission  $bscsExamPermission
     * @return \Illuminate\Http\Response
     */
    public function show(BscsExamPermission $bscsExamPermission)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BscsExamPermission  $bscsExamPermission
     * @return \Illuminate\Http\Response
     */
    public function edit(BscsExamPermission $bscsExamPermission)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BscsExamPermission  $bscsExamPermission
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BscsExamPermission $bscsExamPermission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BscsExamPermission  $bscsExamPermission
     * @return \Illuminate\Http\Response
     */
    public function destroy(BscsExamPermission $bscsExamPermission)
    {
        //
    }
}
