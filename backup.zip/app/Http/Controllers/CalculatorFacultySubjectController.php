<?php

namespace App\Http\Controllers;

use App\CalculatorFacultySubject;
use Illuminate\Http\Request;

class CalculatorFacultySubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CalculatorFacultySubject  $calculatorFacultySubject
     * @return \Illuminate\Http\Response
     */
    public function show(CalculatorFacultySubject $calculatorFacultySubject)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CalculatorFacultySubject  $calculatorFacultySubject
     * @return \Illuminate\Http\Response
     */
    public function edit(CalculatorFacultySubject $calculatorFacultySubject)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CalculatorFacultySubject  $calculatorFacultySubject
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CalculatorFacultySubject $calculatorFacultySubject)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CalculatorFacultySubject  $calculatorFacultySubject
     * @return \Illuminate\Http\Response
     */
    public function destroy(CalculatorFacultySubject $calculatorFacultySubject)
    {
        //
    }
}
