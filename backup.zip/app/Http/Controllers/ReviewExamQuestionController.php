<?php

namespace App\Http\Controllers;

use App\ReviewExamQuestion;
use Illuminate\Http\Request;

class ReviewExamQuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ReviewExamQuestion  $reviewExamQuestion
     * @return \Illuminate\Http\Response
     */
    public function show(ReviewExamQuestion $reviewExamQuestion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ReviewExamQuestion  $reviewExamQuestion
     * @return \Illuminate\Http\Response
     */
    public function edit(ReviewExamQuestion $reviewExamQuestion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ReviewExamQuestion  $reviewExamQuestion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ReviewExamQuestion $reviewExamQuestion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ReviewExamQuestion  $reviewExamQuestion
     * @return \Illuminate\Http\Response
     */
    public function destroy(ReviewExamQuestion $reviewExamQuestion)
    {
        //
    }
}
