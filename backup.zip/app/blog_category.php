<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class blog_category extends Model
{
    protected $fillable = ['title', 'description'];
}
