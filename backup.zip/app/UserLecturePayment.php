<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserLecturePayment extends Model
{
    //
}
