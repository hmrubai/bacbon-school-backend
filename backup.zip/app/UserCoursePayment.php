<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserCoursePayment extends Model
{
    //
}
